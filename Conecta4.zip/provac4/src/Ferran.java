import java.awt.Color;
import java.sql.Struct;





public class Ferran implements Jugador{
    //tabla
    private int taula[][] = new int[8][8];
    //tabla para los punteros
    private int punteros[][][] = new int[8][8][8];
    //La primera cordenada de punteros es el hijo, las dos siguientes son la x 
    //i la y de la tabla
    
    
    

    public int moviment(Tauler t, int color){
        Ferran arrel = new Ferran();
        int tabla[][] = new int[8][8];
        arrel.taula=llegir_tauler(t);
        print_tauler(arrel.taula);
        return 0;   
       
       
        
            
    }
        
    

  
    public String nom(){
        return "Ferran i Dani";
    }

  private static int[][] llegir_tauler(Tauler t){
       int tabla[][] = new int[8][8];
       for(int y=0;y<8;y++){
           for(int x=0;x<8;x++){
              tabla[x][y]=t.getColor(7-x,y);
              
           }
       }
       return tabla;
  }
  private static void print_tauler(int[][] tabla){
      for(int u=0;u<8;u++){
           for(int n=0;n<8;n++){
               System.out.print(tabla[u][n]);
           }
           System.out.print("\n");
       }
       System.out.println("");
  }
  
}