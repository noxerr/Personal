

package valor2;

public class Entero {
    public int valor;
    public Entero(int valor){
        this.valor=valor;
    }
}

