

package polimorfismo1;

public interface Parlanchin {
    public abstract void habla();
}
