//�rea de un c�rculo

package circulo;

public class CirculoApp {
    public static void main(String[] args) {
	    Circulo circulo=new Circulo(2.3);
	    System.out.println("�rea: "+circulo.calcularArea());

        try  {
//espera la pulsaci�n de una tecla y luego RETORNO
            System.in.read();
        }catch (Exception e) {
        }
    }
}

 