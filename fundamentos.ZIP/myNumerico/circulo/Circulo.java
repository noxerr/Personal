

package circulo;

public class Circulo {
        static final double PI=3.1416;
        double radio;
	Circulo(double radio){
		this.radio=radio;
	}
  	double calcularArea(){
		return (PI*radio*radio);
  	}
}
